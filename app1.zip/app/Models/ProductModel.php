<?php

namespace App\Models;

use CodeIgniter\Model;

class ProductModel extends Model
{
	protected $table = 'product';
	protected $primaryKey = 'id';
	protected $allowedFields = [
		'nama', 'harga', 'jumlah', 'foto', 'created_at', 'updated_at'
	];

	// protected $validationRules
	// = [
	// 	'nama' => 'required|min_length[6]',
	// 	'harga' => 'required|numeric',
	// 	'jumlah' => 'required|numeric'
	// ];
}
